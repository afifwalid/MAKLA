import 'package:flutter/material.dart';
import 'recipe_detail_screen.dart'; // أضف هذا السطر

class RecipeListScreen extends StatelessWidget {
  final String proteinType;
  final int peopleCount;

  const RecipeListScreen({
    Key? key,
    required this.proteinType,
    required this.peopleCount,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<String> recipes = _getRecipes(proteinType, peopleCount);

    return Scaffold(
      appBar: AppBar(
        title: const Text('اقتراحات الوصفات'),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/dall.png', // ضع مسار الصورة هنا
            fit: BoxFit.cover,
          ),
          recipes.isEmpty
              ? const Center(
                  child: Text(
                    'لا توجد وصفات متاحة لهذا الاختيار.',
                    style: TextStyle(fontSize: 30, color: Color(0xff1f5009)),
                  ),
                )
              : ListView.builder(
                  itemCount: recipes.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(
                        recipes[index],
                        style: const TextStyle(color: Color(0xff075507)),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => RecipeDetailScreen(
                              recipeName: recipes[index], // تم تمرير اسم الوصفة
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
        ],
      ),
    );
  }

  List<String> _getRecipes(String protein, int count) {
    // خريطة الوصفات بناءً على نوع البروتين
    Map<String, List<String>> recipeMap = {
      'لحم': ['كفتة مشوية', 'طاجين اللحم', 'لحم بالخضار'],
      'دجاج': ['دجاج مشوي', 'طاجين الدجاج', 'شوربة الدجاج'],
      'سمك': ['سمك مقلي', 'سمك مشوي', 'طاجين السمك'],
      'بيض': ['أومليت', 'بيض مسلوق مع صوص', 'بيض بالخضار'],
      'لاشيء': ['شوربة خضار', 'سلطة متنوعة', 'مكرونة بالخضار'],
    };

    // إرجاع قائمة الوصفات أو قائمة فارغة إذا لم يتم العثور على البروتين
    return recipeMap[protein] ?? [];
  }
}
