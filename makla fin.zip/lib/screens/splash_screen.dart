import 'dart:async';
import 'package:flutter/material.dart';
import 'meal_selection_screen.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Timer(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const MealSelectionScreen()),
      );
    });

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/dall.png',
            fit: BoxFit.cover,
          ),
          const Center(
            child: Text(
              'مرحبًا بكم. راكي حايرة واش طيبي اليوم؟',
              style: TextStyle(
                fontSize: 32, // حجم الخط
                color: Colors.white, // لون الخط
                fontWeight: FontWeight.bold, // نوع الخط (ثقيل)
                shadows: [
                  Shadow(
                    offset: Offset(2, 2), // ظل لتوضيح النص
                    color: Colors.black54,
                    blurRadius: 4,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
